/**
  ******************************************************************************
  * @file   fatfs.c
  * @brief  Code for fatfs applications
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

#include "fatfs.h"

uint8_t retUSER;    /* Return value for USER */
char USERPath[4];   /* USER logical drive path */
FATFS USERFatFS;    /* File system object for USER logical drive */
FIL USERFile;       /* File object for USER */

/* USER CODE BEGIN Variables */
#define DEFAULT_DIR "0:/userfile"
#define DEFAULT_LUA_DIR "0:/luafile"

void Write_TXT_File(char *filename,char *str,uint8_t mode)
{
    FIL f_txt;      //�ļ�
    DIR dir;
    UINT br;
    char * file;
    uint8_t res = 0;
    file = filename;

    res=f_open(&f_txt,(const TCHAR*)file,FA_READ|FA_WRITE);     //�Զ���ʽ���ļ�
    if(res == FR_NO_FILE)
    {
        res=f_open(&f_txt,(const TCHAR*)file,FA_READ|FA_WRITE|FA_CREATE_NEW);   //�����µ��ļ�
    }
    if(res == FR_OK)
    {
        f_lseek(&f_txt,f_txt.fsize);              //ָ���ļ���ĩβ
        if(mode & 0x80)
        {
            f_write(&f_txt,"\r\n",strlen((const char*)"\r\n"),(UINT*)&br);
        }
        f_write(&f_txt,str,strlen((const char*)str),(UINT*)&br);    //д������
    }
    f_close(&f_txt);
}

/* USER CODE END Variables */

void MX_FATFS_Init(void)
{
  /*## FatFS: Link the USER driver ###########################*/
  retUSER = FATFS_LinkDriver(&USER_Driver, USERPath);

  /* USER CODE BEGIN Init */
    /* additional user code for init */
    f_mount(&USERFatFS,USERPath,1);
    
    DIR dir;
    uint8_t res = 0;
    
    res=f_opendir(&dir,(const TCHAR*)DEFAULT_DIR);
    if(res == FR_NO_PATH)
    {
        f_closedir(&dir);
        res=f_mkdir((const TCHAR*)DEFAULT_DIR);   //�����µ��ļ���
    }
    f_closedir(&dir);
    res=f_opendir(&dir,(const TCHAR*)DEFAULT_LUA_DIR);
    if(res == FR_NO_PATH)
    {
        f_closedir(&dir);
        res=f_mkdir((const TCHAR*)DEFAULT_LUA_DIR);   //�����µ�LUA�ļ���
    }
    f_closedir(&dir);
    
    Write_TXT_File("0:/test.txt","001 Abc",0x80);
  /* USER CODE END Init */
}

/**
  * @brief  Gets Time from RTC
  * @param  None
  * @retval Time in DWORD
  */
DWORD get_fattime(void)
{
  /* USER CODE BEGIN get_fattime */
    return 0;
  /* USER CODE END get_fattime */
}

/* USER CODE BEGIN Application */

/* USER CODE END Application */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
