/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "fatfs.h"
#include "rtc.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "usb_device.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

__IO uint8_t key = 0;

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
//    if(GPIO_PIN_0 == GPIO_Pin)
//    {
//        key = 1;
//    }
}

__IO uint32_t Battery_adc;
__IO uint8_t adc_flag = 0;

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
    adc_flag = 1;
    HAL_ADC_Start_DMA(&hadc1,(uint32_t *)&Battery_adc,1);
}

const char test_text[] = "File Test";

void test_fatfs(void)
{
    FIL f_txt;  //�ļ�
    char file_name[] = "0:file_test.txt";
    char * file;
    uint8_t rval = 0,res = 0;
    char read_buf[200];
    UINT br;
    file = file_name;
    //����ʧ��
    if(rval == 0)
    {
        res=f_open(&f_txt,(const TCHAR*)file,FA_READ);  //�Զ���ʽ���ļ�
        if(res == FR_OK)
        {
            res=f_read(&f_txt,read_buf,f_txt.fsize,(UINT*)&br); //����txt���������
            f_close(&f_txt);//�ر��ļ�
            show_str(0,48,read_buf,16,1);
            OLED_Refresh_Gram();
            HAL_Delay(500);
        }
        else if(res == FR_NO_FILE)  //�ļ�������
        {
            f_close(&f_txt);
            show_str(0,48,"File Open Fail ",16,1);
            OLED_Refresh_Gram();
            HAL_Delay(500);
            res=f_open(&f_txt,(const TCHAR*)file,FA_READ|FA_WRITE|FA_CREATE_NEW);   //�����µ��ļ�
            if(res == FR_OK)
            {
                f_lseek(&f_txt,0);  //ָ���ļ��Ŀ�ʼ��ַ
                f_write(&f_txt,test_text,strlen((const char*)test_text),(UINT*)&br);    //�����ļ�
                f_close(&f_txt);
            }
        }
    }
}

void OLED_Set_Pos(uint8_t x, uint8_t y)
{
    OLED_WR_Byte(0xb0+y,OLED_CMD);
    OLED_WR_Byte(((x&0xf0)>>4)|0x10,OLED_CMD);
    OLED_WR_Byte((x&0x0f)|0x01,OLED_CMD);
}

void OLED_DrawBMP(uint8_t x0, uint8_t y0,uint8_t x1, uint8_t y1,uint8_t BMP[])
{
    uint32_t j=0;
    uint8_t x,y;

    if(y1%8==0) y=y1/8;
    else y=y1/8+1;
    for(y=y0; y<y1; y++)
    {
        OLED_Set_Pos(x0,y);
        for(x=x0; x<x1; x++)
        {
            OLED_WR_Byte(BMP[j++],OLED_DATA);
        }
    }
}

void badapple_play(void)
{
    unsigned char G_Bin[1024];                      //BINͼ���Դ�
    FRESULT res;
    FIL fsrc;
    uint32_t ls_move=0;                         //�洢�ļ�ָ���ƶ�
    UINT br;
    res = f_open( &fsrc, "0:/badapple.bin", FA_READ);
    if (res==FR_OK)
    {
        OLED_WR_Byte(0xA1,OLED_CMD);    //���ض�������,bit0:0,0->0;1,0->127;
        OLED_WR_Byte(0xC8,OLED_CMD);    //����COMɨ�跽��;bit3:0,��ͨģʽ;1,�ض���ģʽ COM[N-1]->COM0;N:����·��
        while(1)
        {
            res=f_lseek(&fsrc,ls_move);
            res=f_read(&fsrc,G_Bin,sizeof(G_Bin),&br);//��ȡBin���ݷ���G_Bin������
            if(br != 1024)
            {
                ls_move=0;
                break;
            }
            OLED_DrawBMP(0,0,128,8,G_Bin);
            HAL_Delay(20);
            ls_move+=1024;
        }
        OLED_WR_Byte(0xA1,OLED_CMD); //���ض�������,bit0:0,0->0;1,0->127;   0xA0<-->0xA1
        OLED_WR_Byte(0xC0,OLED_CMD); //����COMɨ�跽��; 0xC0<-->0xC1:��ֱ����
    }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
    /* USER CODE BEGIN 1 */
    uint16_t i;
    char str_buf[120];

    float battery;

    float pitch,roll,yaw;       //ŷ����
    short aacx,aacy,aacz;       //���ٶȴ�����ԭʼ����
    short gyrox,gyroy,gyroz;    //������ԭʼ����
    short temp;                 //�¶�
    /* USER CODE END 1 */

    /* MCU Configuration--------------------------------------------------------*/

    /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
    HAL_Init();

    /* USER CODE BEGIN Init */

    /* USER CODE END Init */

    /* Configure the system clock */
    SystemClock_Config();

    /* USER CODE BEGIN SysInit */

    /* USER CODE END SysInit */

    /* Initialize all configured peripherals */
    MX_GPIO_Init();
    MX_DMA_Init();
    MX_ADC1_Init();
    MX_RTC_Init();
    MX_SPI1_Init();
    MX_SPI2_Init();
    MX_USART1_UART_Init();
    MX_TIM2_Init();
    /* USER CODE BEGIN 2 */
    OLED_Init();
    OLED_Clear();
    OLED_ShowString(0,0,"Mini Watch V1.0",16);
    show_str(0,16,"OLED������",16,1);
    OLED_Refresh_Gram();

    HAL_ADC_Start_DMA(&hadc1,(uint32_t *)&Battery_adc,1);
    W25QXX_Init();
    MX_FATFS_Init();
    MX_USB_DEVICE_Init();

MPUinit:
    Set_MPU(1);
    i = MPU_Init();
    if(i == 0)
    {
        show_str(0,32,"MPU1  OK",16,1);
        OLED_Refresh_Gram();
    }
    else
    {
        sprintf(str_buf,"MPU1:%3d",i);
        show_str(0,32,str_buf,16,1);
        OLED_Refresh_Gram();
        HAL_Delay(100);
        goto MPUinit;
    }
DMPinit:
    i = mpu_dmp_init();
    if(i == 0)
    {
        show_str(0,32,"DMP1  OK",16,1);
        OLED_Refresh_Gram();
    }
    else
    {
        sprintf(str_buf,"DMP1:%3d",i);
        show_str(0,32,str_buf,16,1);
        OLED_Refresh_Gram();
        HAL_Delay(100);
        goto DMPinit;
    }

    /* USER CODE END 2 */

    /* Infinite loop */
    /* USER CODE BEGIN WHILE */
    while (1)
    {
        /* USER CODE END WHILE */

        /* USER CODE BEGIN 3 */
//        if(mpu_dmp_get_data(&pitch,&roll,&yaw)==0)
//        {
//            temp=MPU_Get_Temperature();                 //�õ��¶�ֵ
//            //MPU_Get_Accelerometer(&aacx,&aacy,&aacz);   //�õ����ٶȴ���������
//            //MPU_Get_Gyroscope(&gyrox,&gyroy,&gyroz);    //�õ�����������
//            sprintf(str_buf,"M1:%4.1f,%4.1f,%4.1f,%4.1f",pitch,roll,yaw,(float)temp/100);
//            show_str(0,32,str_buf,16,1);
//        }
//        HAL_ADC_Start(&hadc1);
//        if(HAL_OK == HAL_ADC_PollForConversion(&hadc1,0xFF))
//        {
//            uint32_t adc = HAL_ADC_GetValue(&hadc1);
//            battery = (float)adc * 2 * 0.8056640625f;//3300 / 4096;
//            sprintf(str_buf,"��ѹ:%.2f",(float)battery/1000);
//            show_str(0,32,str_buf,16,1);
//        }
//        HAL_ADC_Stop(&hadc1);
        if(adc_flag == 1)
        {
            adc_flag = 0;
            battery = (float)(Battery_adc&(0xFFFF)) * 2 * 0.8056640625f;//3300 / 4096;
            sprintf(str_buf,"��ѹ:%.2f",(float)battery/1000);
            show_str(0,32,str_buf,16,1);
        }
        if(HAL_GPIO_ReadPin(KEY_GPIO_Port,KEY_Pin) == 0)
        {
            show_str(0,48,"Key",16,1);
            key = 1;
        }
        else
        {
            key = 0;
            show_str(0,48,"   ",16,1);
        }
        OLED_Refresh_Gram();
        HAL_Delay(100);
    }
    /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
    RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

    /** Initializes the RCC Oscillators according to the specified parameters
    * in the RCC_OscInitTypeDef structure.
    */
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
    RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.LSIState = RCC_LSI_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }
    /** Initializes the CPU, AHB and APB buses clocks
    */
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                                  |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
    {
        Error_Handler();
    }
    PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC|RCC_PERIPHCLK_ADC
                                         |RCC_PERIPHCLK_USB;
    PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
    PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
    PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL_DIV1_5;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
    {
        Error_Handler();
    }
}

/* USER CODE BEGIN 4 */

const uint8_t modern_dig_15x32[] = {
    -15, 32, '0', '0'+10,  // -width, height, firstChar, lastChar
        0x0F, 0x00, 0xFE, 0x7F, 0x00, 0xE0, 0x01, 0x80, 0x07, 0x18, 0x00, 0x00, 0x18, 0x04, 0x00, 0x00, 0x20, 0x02, 0x00, 0x00, 0x40, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x02, 0x00, 0x00, 0x40, 0x04, 0x00, 0x00, 0x20, 0x18, 0x00, 0x00, 0x18, 0xE0, 0x01, 0x80, 0x07, 0x00, 0xFE, 0x7F, 0x00,  // Code for char 0
        0x0f, 0x00, 0x01, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // Code for char 1
        0x0f, 0x00, 0x00, 0x00, 0xC0, 0xE0, 0x00, 0x00, 0xA0, 0x18, 0x00, 0x00, 0x90, 0x04, 0x00, 0x00, 0x8C, 0x02, 0x00, 0x00, 0x82, 0x01, 0x00, 0x80, 0x81, 0x01, 0x00, 0x40, 0x80, 0x01, 0x00, 0x30, 0x80, 0x01, 0x00, 0x08, 0x80, 0x01, 0x00, 0x06, 0x80, 0x02, 0x80, 0x01, 0x80, 0x0C, 0x60, 0x00, 0x80, 0x30, 0x1C, 0x00, 0x80, 0xC0, 0x03, 0x00, 0x80, 0x00, 0x00, 0x00, 0x00,  // Code for char 2
        0x0F, 0x00, 0x00, 0x00, 0x0C, 0x00, 0x00, 0x00, 0x30, 0x01, 0x00, 0x00, 0x40, 0x01, 0x00, 0x00, 0x40, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x18, 0x00, 0x80, 0x01, 0x16, 0x00, 0x80, 0x81, 0x11, 0x00, 0x40, 0x61, 0x10, 0x00, 0x40, 0x19, 0x20, 0x00, 0x20, 0x07, 0x40, 0x00, 0x18, 0x00, 0x80, 0x07, 0x07, 0x00, 0x00, 0xF8, 0x00,  // Code for char 3
        0x0F, 0x00, 0x00, 0x38, 0x00, 0x00, 0x00, 0x26, 0x00, 0x00, 0x80, 0x21, 0x00, 0x00, 0x60, 0x20, 0x00, 0x00, 0x18, 0x20, 0x00, 0x00, 0x06, 0x20, 0x00, 0x80, 0x01, 0x20, 0x00, 0x60, 0x00, 0x20, 0x00, 0x18, 0x00, 0x20, 0x00, 0x06, 0x00, 0x20, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x20, 0x00,  // Code for char 4
        0x0F, 0x00, 0x00, 0x00, 0x0C, 0xC0, 0x3F, 0x00, 0x30, 0x3F, 0x10, 0x00, 0x40, 0x01, 0x08, 0x00, 0x40, 0x01, 0x08, 0x00, 0x80, 0x01, 0x04, 0x00, 0x80, 0x01, 0x04, 0x00, 0x80, 0x01, 0x04, 0x00, 0x80, 0x01, 0x08, 0x00, 0x80, 0x01, 0x08, 0x00, 0x40, 0x01, 0x10, 0x00, 0x40, 0x01, 0x20, 0x00, 0x20, 0x00, 0x40, 0x00, 0x18, 0x00, 0x80, 0x07, 0x07, 0x00, 0x00, 0xF8, 0x00,  // Code for char 5
        0x0f, 0x00, 0xFE, 0xFF, 0x01, 0xE0, 0x01, 0x07, 0x0E, 0x18, 0xC0, 0x00, 0x30, 0x04, 0x20, 0x00, 0x40, 0x02, 0x20, 0x00, 0x40, 0x02, 0x10, 0x00, 0x80, 0x01, 0x10, 0x00, 0x80, 0x01, 0x10, 0x00, 0x80, 0x01, 0x20, 0x00, 0x40, 0x02, 0x20, 0x00, 0x40, 0x02, 0x40, 0x00, 0x20, 0x0C, 0x80, 0x01, 0x18, 0x10, 0x00, 0x0E, 0x07, 0x00, 0x00, 0xF0, 0x00, 0x00, 0x00, 0x00, 0x00,  // Code for char 6
        0x0f, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0xE0, 0x01, 0x00, 0x00, 0x1C, 0x01, 0x00, 0x80, 0x03, 0x01, 0x00, 0x70, 0x00, 0x01, 0x00, 0x0E, 0x00, 0x01, 0xC0, 0x01, 0x00, 0x01, 0x3C, 0x00, 0x00, 0x81, 0x03, 0x00, 0x00, 0x71, 0x00, 0x00, 0x00, 0x0F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // Code for char 7
        0x0F, 0x00, 0x00, 0xE0, 0x03, 0xE0, 0x00, 0x1C, 0x1C, 0x1C, 0x07, 0x03, 0x20, 0x02, 0x88, 0x00, 0x40, 0x02, 0x50, 0x00, 0x40, 0x01, 0x50, 0x00, 0x80, 0x01, 0x20, 0x00, 0x80, 0x01, 0x20, 0x00, 0x80, 0x01, 0x20, 0x00, 0x80, 0x01, 0x50, 0x00, 0x80, 0x02, 0x50, 0x00, 0x40, 0x02, 0x88, 0x00, 0x40, 0x1C, 0x07, 0x03, 0x20, 0xE0, 0x00, 0x1C, 0x1C, 0x00, 0x00, 0xE0, 0x03,  // Code for char 8
        0x0f, 0x80, 0x3F, 0x00, 0x00, 0x70, 0xC0, 0x00, 0x18, 0x08, 0x00, 0x03, 0x20, 0x04, 0x00, 0x04, 0x40, 0x02, 0x00, 0x04, 0x80, 0x02, 0x00, 0x08, 0x80, 0x01, 0x00, 0x08, 0x80, 0x01, 0x00, 0x08, 0x80, 0x02, 0x00, 0x08, 0x40, 0x02, 0x00, 0x04, 0x40, 0x04, 0x00, 0x02, 0x30, 0x18, 0x00, 0x01, 0x0C, 0x60, 0x80, 0x00, 0x03, 0x80, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00,  // Code for char 9
        0x05, 0x00, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x01, 0xC0, 0x01, 0x80, 0x03, 0x80, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // Code for char :
    };

const uint8_t seg7_dig_15x32[] = {
    -15, 32, '0', '0'+10,  // -width, height, firstChar, lastChar
        0x0F, 0xFE, 0x7F, 0xFF, 0x7F, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0x01, 0x00, 0x00, 0x80, 0xFE, 0x7F, 0xFF, 0x7F,  // Code for char 0
        0x0F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFE, 0x7F, 0xFF, 0x7F,  // Code for char 1
        0x0F, 0x00, 0x00, 0xFF, 0x7F, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0xFE, 0x7F, 0x00, 0x00,  // Code for char 2
        0x0F, 0x00, 0x00, 0x00, 0x00, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0xFE, 0x7F, 0xFF, 0x7F,  // Code for char 3
        0x0F, 0xFE, 0x7F, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0xFE, 0x7F, 0xFF, 0x7F,  // Code for char 4
        0x0F, 0xFE, 0x7F, 0x00, 0x00, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x00, 0x00, 0xFF, 0x7F,  // Code for char 5
        0x0F, 0xFE, 0x7F, 0xFF, 0x7F, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x00, 0x00, 0xFF, 0x7F,  // Code for char 6
        0x0F, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0xFE, 0x7F, 0xFF, 0x7F,  // Code for char 7
        0x0F, 0xFE, 0x7F, 0xFF, 0x7F, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0xFE, 0x7F, 0xFF, 0x7F,  // Code for char 8
        0x0F, 0xFE, 0x7F, 0x00, 0x00, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0x01, 0x80, 0x00, 0x80, 0xFE, 0x7F, 0xFF, 0x7F,  // Code for char 9
        0x05, 0x00, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x01, 0xC0, 0x01, 0x80, 0x03, 0x80, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,  // Code for char :
    };

const uint8_t *font = modern_dig_15x32;
//const uint8_t *font = seg7_dig_15x32;

uint8_t buf[15*4];
uint8_t bufWd = 15;
uint8_t bufHt = 4;

void clrBuf(void)
{
    int ii=0;
    for(int i=0; i<bufWd*bufHt/4; i++) {
        buf[ii++]=0;
        buf[ii++]=0;
        buf[ii++]=0;
        buf[ii++]=0;
    }
}

void drawPixel(int16_t x, int16_t y, uint16_t color)
{
    if(x<0 || x>=bufWd || y<0 || y>=bufHt*8)
        return;
    switch(color) {
    case 1:
        buf[x+(y/8)*bufWd] |=  (1 << (y&7));
        break;
    case 0:
        buf[x+(y/8)*bufWd] &= ~(1 << (y&7));
        break;
    case 2:
        buf[x+(y/8)*bufWd] ^=  (1 << (y&7));
        break;
    }
}

uint8_t convertPolish(uint8_t _c)
{
    uint8_t dualChar;
    unsigned char pl, c = _c;
    if(c==196 || c==197 || c==195) {
        dualChar = c;
        return 0;
    }
    if(dualChar) { // UTF8 coding
        switch(_c) {
        case 133:
            pl = 1+9;
            break; // '?
        case 135:
            pl = 2+9;
            break; // '?
        case 153:
            pl = 3+9;
            break; // '?
        case 130:
            pl = 4+9;
            break; // '?
        case 132:
            pl = dualChar==197 ? 5+9 : 1;
            break; // '? and '?
        case 179:
            pl = 6+9;
            break; // '?
        case 155:
            pl = 7+9;
            break; // '?
        case 186:
            pl = 8+9;
            break; // '?
        case 188:
            pl = 9+9;
            break; // '?
        //case 132: pl = 1; break; // '?
        case 134:
            pl = 2;
            break; // '?
        case 152:
            pl = 3;
            break; // '?
        case 129:
            pl = 4;
            break; // '?
        case 131:
            pl = 5;
            break; // '?
        case 147:
            pl = 6;
            break; // '?
        case 154:
            pl = 7;
            break; // '?
        case 185:
            pl = 8;
            break; // '?
        case 187:
            pl = 9;
            break; // '?
        default:
            return c;
            break;
        }
        dualChar = 0;
    } else
        switch(_c) {  // Windows coding
        case 165:
            pl = 1;
            break; // ?
        case 198:
            pl = 2;
            break; // ?
        case 202:
            pl = 3;
            break; // ?
        case 163:
            pl = 4;
            break; // ?
        case 209:
            pl = 5;
            break; // ?
        case 211:
            pl = 6;
            break; // ?
        case 140:
            pl = 7;
            break; // ?
        case 143:
            pl = 8;
            break; // ?
        case 175:
            pl = 9;
            break; // ?
        case 185:
            pl = 10;
            break; // ?
        case 230:
            pl = 11;
            break; // ?
        case 234:
            pl = 12;
            break; // ?
        case 179:
            pl = 13;
            break; // ?
        case 241:
            pl = 14;
            break; // ?
        case 243:
            pl = 15;
            break; // ?
        case 156:
            pl = 16;
            break; // ?
        case 159:
            pl = 17;
            break; // ?
        case 191:
            pl = 18;
            break; // ?
        default:
            return c;
            break;
        }
    return pl+'~'+1;
}

int genPoints(uint8_t *tab, int max, const uint8_t* font, char c)
{
    uint8_t xSize    =- *(font+0);
    uint8_t ySize    = *(font+1);
    uint8_t offs     = *(font+2);
    uint8_t numChars = *(font+3);
    uint8_t ySize8 = (ySize+7)/8;
    uint8_t wd, ch = convertPolish(c);
    if(!font || ch<offs || ch>=offs+numChars) return 0;
    int v;
    int num = 0;
    int i, idx = 4 + (ch - offs)*(xSize*ySize8+1)+1;
    //wd = pgm_read_byte(font + idx++);
    wd = xSize;
    for(int j=0; j<ySize8; j++)
    {
        for(i=0; i<wd; i++)
        {
            v = *(font + idx + i * ySize8 + j);
            uint8_t mask = 1;
            for(int b=0; b<8; b++)
            {
                if(v & mask)
                {
                    tab[num*2+0] = i;
                    tab[num*2+1] = b+j*8;
                    if(++num>=max)
                    {
                        printf("Size too big for:%c",ch);
                        return num;
                    }
                    mask<<=1;
                }
            }
        }
    }
    return num;
}

void drawPoints(int x, int y, uint8_t *from, int num)
{
    for(int i=0; i<num; i++)
    {
        drawPixel( x+from[i*2], y+from[i*2+1], 1 );
    }
}

#define TAB_MAX 100
uint8_t src[TAB_MAX*2];
uint8_t dst[TAB_MAX*2];
int numSrc=0;
int numDst=0;
int tt=0;

unsigned int h,m,s;
unsigned long startTime=16*3600L+58*60+50;
unsigned long startMillis;
char digits[7];
char digitsOld[7];
int digitX[8];

void tick(void)
{
    unsigned long tim=startTime+(HAL_GetTick()-startMillis)/1000;
    h=tim/3600;
    m=(tim-h*3600)/60;
    s=tim-h*3600-m*60;
    strcpy(digitsOld,digits);
    snprintf(digits,7,"%02u%02u%02u",h,m,s);
    //Serial.println(digits);
}

void morph(int digX, int mode)
{
    int i,i0,i1,x,y;
    int n = (numSrc>numDst) ? numSrc : numDst;

    clrBuf();
    for(int i=0; i<n; i++) {
        i0 = (numSrc<n) ? i*numSrc/n : i;
        i1 = (numDst<n) ? i*numDst/n : i;
        if(mode&1) i1 = numDst-1-i1;
        x = src[i0*2]+(dst[i1*2]-src[i0*2])*tt/32;
        y = src[i0*2+1]+(dst[i1*2+1]-src[i0*2+1])*tt/32;
        drawPixel(x,y,1);
    }
    //oled.drawBuf(buf,digX,2,bufWd,bufHt);
}

void showClock()
{
    for(int i=0; i<8; i++)
    {
        //oled.printChar(digitX[i], 2, i<6 ? digits[i] : ':');
    }
}

void init_clock(void)
{
    // 17+17+6+17+17+6+17+17
    int x = 6;
    digitX[0]=x;
    digitX[1]=17+digitX[0];
    digitX[6]=17+digitX[1];
    digitX[2]= 7+digitX[6];
    digitX[3]=17+digitX[2];
    digitX[7]=17+digitX[3];
    digitX[4]= 7+digitX[7];
    digitX[5]=17+digitX[4];
    showClock();
}

int mode = 0;
void loop()
{
    // morph demo
    tick();
    for(tt=0; tt<=32; tt++)
    {
        unsigned long morphStart = HAL_GetTick();
        // one buffer for all digits - not optimal and slow but saves memory
        for(int i=0; i<6; i++)
        {
            if(digits[i]!=digitsOld[i])
            {
                numSrc = genPoints(src,TAB_MAX,font,digitsOld[i]);
                numDst = genPoints(dst,TAB_MAX,font,digits[i]);
                morph(digitX[i],mode);
            }
        }
        while(HAL_GetTick()-morphStart<10) {}
    }
    // next mode at 17:00:11
    if(m==00 && s>11)
    {
        mode=(mode+1) & 0x03;
        font = mode < 2 ? modern_dig_15x32 : seg7_dig_15x32;
        startMillis=HAL_GetTick();
        startTime=16*3600L+59*60+35;
        tick();
        strcpy(digitsOld,digits);
        //oled.setFont(font);
        showClock();
    }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
    /* USER CODE BEGIN Error_Handler_Debug */
    /* User can add his own implementation to report the HAL error return state */
    __disable_irq();
    while (1)
    {
    }
    /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
    /* USER CODE BEGIN 6 */
    /* User can add his own implementation to report the file name and line number,
       ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
    /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
